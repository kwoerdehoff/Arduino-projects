This folder contains the list of example Arduino sketches and makefile showing the different usage patterns

- Blink - Shows normal usage
- HelloWorld - Shows how to include Arduino libraries
- BlinkInAVRC - Shows how to use plain AVR C code
- BlinkChipKIT - Shows how to use ChipKIT
- ATtinyBlink - Shows how to use different cores like ATtiny
